import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Filter, Clock, User, ArrowRight, TrendingUp, BookOpen, Video, FileText } from 'lucide-react';
import { ParticleBackground } from '../components/ParticleBackground';

export const BlogPage: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const categories = [
    { id: 'all', label: 'All Posts', count: 156 },
    { id: 'defi', label: 'DeFi', count: 45 },
    { id: 'nft', label: 'NFTs', count: 38 },
    { id: 'blockchain', label: 'Blockchain', count: 52 },
    { id: 'trading', label: 'Trading', count: 21 }
  ];

  const featuredPosts = [
    {
      id: 1,
      title: 'The Evolution of Decentralized Finance: A 2025 Perspective',
      excerpt: 'Exploring how DeFi has transformed traditional finance and what the future holds for decentralized protocols.',
      author: 'Sarah Chen',
      readTime: '12 min read',
      date: '2 days ago',
      category: 'defi',
      image: 'https://images.pexels.com/photos/730547/pexels-photo-730547.jpeg?auto=compress&cs=tinysrgb&w=800',
      featured: true,
      views: '15.2K'
    },
    {
      id: 2,
      title: 'NFT Utility Beyond Digital Art: Real-World Applications',
      excerpt: 'Discover how NFTs are revolutionizing industries beyond art, from gaming to real estate and identity verification.',
      author: 'Alex Rodriguez',
      readTime: '8 min read',
      date: '5 days ago',
      category: 'nft',
      image: 'https://images.pexels.com/photos/7686734/pexels-photo-7686734.jpeg?auto=compress&cs=tinysrgb&w=800',
      featured: true,
      views: '12.8K'
    }
  ];

  const blogPosts = [
    {
      id: 3,
      title: 'Understanding Layer 2 Solutions: Scaling Ethereum for Mass Adoption',
      excerpt: 'A comprehensive guide to Layer 2 scaling solutions and their impact on Ethereum\'s future.',
      author: 'Emma Davis',
      readTime: '10 min read',
      date: '1 week ago',
      category: 'blockchain',
      image: 'https://images.pexels.com/photos/1181677/pexels-photo-1181677.jpeg?auto=compress&cs=tinysrgb&w=600',
      views: '8.5K'
    },
    {
      id: 4,
      title: 'Crypto Trading Psychology: Mastering Your Emotions',
      excerpt: 'Learn how to control emotions and make rational decisions in volatile crypto markets.',
      author: 'David Kim',
      readTime: '7 min read',
      date: '1 week ago',
      category: 'trading',
      image: 'https://images.pexels.com/photos/577585/pexels-photo-577585.jpeg?auto=compress&cs=tinysrgb&w=600',
      views: '6.2K'
    },
    {
      id: 5,
      title: 'Web3 Security: Protecting Your Digital Assets',
      excerpt: 'Essential security practices every crypto user should know to protect their investments.',
      author: 'Lisa Wang',
      readTime: '9 min read',
      date: '2 weeks ago',
      category: 'blockchain',
      image: 'https://images.pexels.com/photos/60504/security-protection-anti-virus-software-60504.jpeg?auto=compress&cs=tinysrgb&w=600',
      views: '9.1K'
    },
    {
      id: 6,
      title: 'The Rise of Decentralized Autonomous Organizations (DAOs)',
      excerpt: 'How DAOs are reshaping governance and community decision-making in Web3.',
      author: 'Michael Torres',
      readTime: '11 min read',
      date: '2 weeks ago',
      category: 'defi',
      image: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=600',
      views: '7.3K'
    }
  ];

  const trendingTopics = [
    { name: 'Layer 2 Solutions', posts: 23 },
    { name: 'DeFi Protocols', posts: 18 },
    { name: 'NFT Marketplaces', posts: 15 },
    { name: 'Crypto Regulation', posts: 12 },
    { name: 'Web3 Gaming', posts: 9 }
  ];

  return (
    <div className="relative min-h-screen">
      <ParticleBackground density={60} colors={['#3b82f6', '#8b5cf6', '#14b8a6']} />
      
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center overflow-hidden pt-20 bg-white dark:bg-gray-900">
        <div className="container mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Left Content */}
            <motion.div
              initial={{ x: -100, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ duration: 1 }}
              className="space-y-8"
            >
              <motion.h1
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.2 }}
                className="text-6xl lg:text-8xl font-black leading-none"
              >
                <span className="bg-gradient-to-r from-purple-400 to-pink-600 bg-clip-text text-transparent">
                  Web3
                </span>
                <br />
                <span className="text-gray-800 dark:text-white">Insights</span>
              </motion.h1>
              
              <motion.p
                initial={{ y: 30, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.4 }}
                className="text-xl text-gray-700 dark:text-gray-300 leading-relaxed max-w-2xl"
              >
                Stay ahead of the curve with expert analysis, market insights, and educational content 
                from the world of Web3 and cryptocurrency.
              </motion.p>

              {/* Search Bar */}
              <motion.div
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.6 }}
                className="relative max-w-md"
              >
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search articles..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-12 pr-4 py-4 rounded-2xl backdrop-blur-xl bg-white/80 dark:bg-white/10 border border-gray-200/20 dark:border-white/20 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500/50"
                />
              </motion.div>
            </motion.div>

            {/* Right Stats */}
            <motion.div
              initial={{ x: 100, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ duration: 1, delay: 0.3 }}
              className="space-y-6"
            >
              {[
                { number: '500+', label: 'Articles', color: 'from-purple-400 to-pink-500' },
                { number: '100K+', label: 'Monthly Readers', color: 'from-blue-400 to-cyan-500' },
                { number: '50+', label: 'Expert Authors', color: 'from-teal-400 to-green-500' },
                { number: '24/7', label: 'Fresh Content', color: 'from-orange-400 to-red-500' }
              ].map((stat, index) => (
                <motion.div
                  key={index}
                  initial={{ scale: 0, rotate: -180 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{ delay: 0.8 + index * 0.1, type: "spring" }}
                  whileHover={{ scale: 1.05, rotate: 5 }}
                  className="backdrop-blur-xl bg-white/80 dark:bg-white/10 rounded-2xl p-6 border border-gray-200/20 dark:border-white/20"
                >
                  <div className={`text-3xl font-black bg-gradient-to-r ${stat.color} bg-clip-text text-transparent mb-2`}>
                    {stat.number}
                  </div>
                  <div className="text-gray-600 dark:text-gray-300 font-medium">{stat.label}</div>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* Category Filter */}
      <section className="relative -mt-20 z-20 pb-20">
        <div className="container mx-auto px-6">
          <motion.div
            initial={{ y: 100, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            className="backdrop-blur-xl bg-white/80 dark:bg-white/10 rounded-3xl p-6 border border-gray-200/20 dark:border-white/20"
          >
            <div className="flex flex-wrap gap-4 justify-center">
              {categories.map((category) => (
                <motion.button
                  key={category.id}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setActiveCategory(category.id)}
                  className={`px-6 py-3 rounded-full font-semibold transition-all ${
                    activeCategory === category.id
                      ? 'bg-gradient-to-r from-purple-500 to-pink-600 text-white'
                      : 'bg-gray-200/50 dark:bg-white/10 text-gray-700 dark:text-gray-300 hover:bg-gray-200/70 dark:hover:bg-white/20'
                  }`}
                >
                  {category.label}
                  <span className="ml-2 text-sm opacity-75">({category.count})</span>
                </motion.button>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Featured Posts */}
      <section className="py-20">
        <div className="container mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-black mb-6">
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Featured Articles
              </span>
            </h2>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-8 mb-20">
            {featuredPosts.map((post, index) => (
              <motion.article
                key={post.id}
                initial={{ y: 100, opacity: 0, scale: 0.8 }}
                whileInView={{ y: 0, opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.2, type: "spring" }}
                whileHover={{ y: -10, scale: 1.02 }}
                className="group relative overflow-hidden rounded-3xl backdrop-blur-xl bg-white/80 dark:bg-white/5 border border-gray-200/20 dark:border-white/10 cursor-pointer"
              >
                <div className="relative h-64 overflow-hidden">
                  <img 
                    src={post.image} 
                    alt={post.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                  <div className="absolute top-4 left-4">
                    <span className="px-3 py-1 bg-gradient-to-r from-purple-500 to-pink-600 text-white text-xs font-bold rounded-full">
                      FEATURED
                    </span>
                  </div>
                  <div className="absolute top-4 right-4 flex items-center space-x-1 text-white text-sm">
                    <TrendingUp className="w-4 h-4" />
                    <span>{post.views}</span>
                  </div>
                </div>
                
                <div className="p-8">
                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4 group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors line-clamp-2">
                    {post.title}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-300 mb-6 line-clamp-3 leading-relaxed">
                    {post.excerpt}
                  </p>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4 text-sm text-gray-500 dark:text-gray-400">
                      <div className="flex items-center space-x-1">
                        <User className="w-4 h-4" />
                        <span>{post.author}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock className="w-4 h-4" />
                        <span>{post.readTime}</span>
                      </div>
                    </div>
                    <span className="text-sm text-gray-500 dark:text-gray-400">{post.date}</span>
                  </div>
                </div>
              </motion.article>
            ))}
          </div>

          {/* Regular Posts Grid */}
          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <div className="grid md:grid-cols-2 gap-8">
                {blogPosts.map((post, index) => (
                  <motion.article
                    key={post.id}
                    initial={{ y: 100, opacity: 0 }}
                    whileInView={{ y: 0, opacity: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                    whileHover={{ y: -10 }}
                    className="group relative overflow-hidden rounded-2xl backdrop-blur-xl bg-white/80 dark:bg-white/5 border border-gray-200/20 dark:border-white/10 cursor-pointer"
                  >
                    <div className="relative h-48 overflow-hidden">
                      <img 
                        src={post.image} 
                        alt={post.title}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>
                      <div className="absolute top-4 right-4 flex items-center space-x-1 text-white text-sm">
                        <TrendingUp className="w-3 h-3" />
                        <span>{post.views}</span>
                      </div>
                    </div>
                    
                    <div className="p-6">
                      <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-3 group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors line-clamp-2">
                        {post.title}
                      </h3>
                      <p className="text-gray-600 dark:text-gray-300 text-sm mb-4 line-clamp-2 leading-relaxed">
                        {post.excerpt}
                      </p>
                      
                      <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400">
                        <div className="flex items-center space-x-2">
                          <span>{post.author}</span>
                          <span>•</span>
                          <span>{post.readTime}</span>
                        </div>
                        <span>{post.date}</span>
                      </div>
                    </div>
                  </motion.article>
                ))}
              </div>
            </div>

            {/* Sidebar */}
            <div className="space-y-8">
              {/* Trending Topics */}
              <motion.div
                initial={{ x: 100, opacity: 0 }}
                whileInView={{ x: 0, opacity: 1 }}
                viewport={{ once: true }}
                className="backdrop-blur-xl bg-white/80 dark:bg-white/10 rounded-2xl p-6 border border-gray-200/20 dark:border-white/20"
              >
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-6">Trending Topics</h3>
                <div className="space-y-4">
                  {trendingTopics.map((topic, index) => (
                    <motion.div
                      key={index}
                      initial={{ x: 20, opacity: 0 }}
                      whileInView={{ x: 0, opacity: 1 }}
                      viewport={{ once: true }}
                      transition={{ delay: index * 0.1 }}
                      whileHover={{ x: 10 }}
                      className="flex items-center justify-between p-3 rounded-lg hover:bg-gray-100/50 dark:hover:bg-white/5 transition-all cursor-pointer"
                    >
                      <span className="text-gray-700 dark:text-gray-300 font-medium">{topic.name}</span>
                      <span className="text-sm text-gray-500 dark:text-gray-400">{topic.posts} posts</span>
                    </motion.div>
                  ))}
                </div>
              </motion.div>

              {/* Newsletter Signup */}
              <motion.div
                initial={{ x: 100, opacity: 0 }}
                whileInView={{ x: 0, opacity: 1 }}
                viewport={{ once: true }}
                className="backdrop-blur-xl bg-gradient-to-br from-purple-500/20 to-pink-500/20 rounded-2xl p-6 border border-purple-200/20 dark:border-purple-700/20"
              >
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Stay Updated</h3>
                <p className="text-gray-600 dark:text-gray-300 text-sm mb-6">
                  Get the latest Web3 insights delivered to your inbox weekly.
                </p>
                <div className="space-y-4">
                  <input
                    type="email"
                    placeholder="Enter your email"
                    className="w-full px-4 py-3 rounded-xl bg-white/50 dark:bg-white/10 border border-gray-200/20 dark:border-white/20 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500/50"
                  />
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="w-full py-3 bg-gradient-to-r from-purple-500 to-pink-600 rounded-xl font-semibold text-white"
                  >
                    Subscribe
                  </motion.button>
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};