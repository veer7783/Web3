import React, { useEffect, useRef } from 'react';
import { motion, useScroll, useTransform, useInView } from 'framer-motion';
import { ArrowRight, Zap, Shield, Coins, TrendingUp, Globe, Cpu } from 'lucide-react';
import { ParticleBackground } from '../components/ParticleBackground';

export const HomePage: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: containerRef });
  
  const y1 = useTransform(scrollYProgress, [0, 1], [0, -200]);
  const y2 = useTransform(scrollYProgress, [0, 1], [0, 200]);
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);

  const features = [
    { icon: Zap, title: 'Lightning Fast', desc: 'Instant transactions' },
    { icon: Shield, title: 'Ultra Secure', desc: 'Military-grade encryption' },
    { icon: Coins, title: 'Multi-Asset', desc: 'Support for 1000+ tokens' },
    { icon: TrendingUp, title: 'Smart Analytics', desc: 'AI-powered insights' },
    { icon: Globe, title: 'Global Access', desc: 'Available worldwide' },
    { icon: Cpu, title: 'Advanced Tech', desc: 'Cutting-edge blockchain' }
  ];

  return (
    <div ref={containerRef} className="relative overflow-hidden">
      <ParticleBackground density={80} />
      
      {/* Hero Section - Asymmetric Layout */}
      <section className="relative min-h-screen flex items-center pt-20 bg-gray-900 dark:bg-gray-900">
        <div className="container mx-auto px-6 grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <motion.div
            initial={{ x: -100, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="space-y-8"
          >
            <div className="space-y-4">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.5, type: "spring" }}
                className="inline-flex items-center px-4 py-2 rounded-full bg-gradient-to-r from-blue-500/20 to-purple-500/20 border border-blue-500/30"
              >
                <Zap className="w-4 h-4 mr-2 text-blue-400" />
                <span className="text-sm text-blue-300">Next-Gen Web3 Platform</span>
              </motion.div>
              
              <motion.h1
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.2, duration: 0.8 }}
                className="text-6xl lg:text-8xl font-black leading-none"
              >
                <span className="bg-gradient-to-r from-blue-400 via-purple-500 to-teal-400 bg-clip-text text-transparent">
                  Future
                </span>
                <br />
                <span className="text-white dark:text-white">of Finance</span>
              </motion.h1>
              
              <motion.p
                initial={{ y: 30, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.4, duration: 0.8 }}
                className="text-gray-200 dark:text-gray-300 max-w-lg leading-relaxed"
              >
                Experience the revolutionary world of decentralized finance with cutting-edge technology and unparalleled security.
              </motion.p>
            </div>

            <motion.div
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.6, duration: 0.8 }}
              className="flex flex-col sm:flex-row gap-4"
            >
              <motion.button
                whileHover={{ scale: 1.05, boxShadow: "0 20px 40px rgba(59, 130, 246, 0.3)" }}
                whileTap={{ scale: 0.95 }}
                className="group relative px-8 py-4 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full font-semibold text-white overflow-hidden"
              >
                <span className="relative z-10 flex items-center">
                  Start Trading
                  <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-purple-600 to-blue-500 opacity-0 group-hover:opacity-100 transition-opacity"></div>
              </motion.button>
              
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-4 border-2 border-teal-500 text-teal-400 rounded-full font-semibold hover:bg-teal-500 hover:text-white transition-all"
              >
                Learn More
              </motion.button>
            </motion.div>
          </motion.div>

          {/* Right Visual */}
          <motion.div
            style={{ y: y1 }}
            className="relative"
          >
            <div className="relative w-full h-96 lg:h-[500px]">
              {/* Floating Cards */}
              {features.map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ scale: 0, rotate: -180 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{ 
                    delay: 0.8 + index * 0.1, 
                    type: "spring",
                    stiffness: 100
                  }}
                  whileHover={{ 
                    scale: 1.1, 
                    rotate: 5,
                    zIndex: 10
                  }}
                  className={`absolute backdrop-blur-xl bg-white/10 rounded-2xl p-6 border border-white/20 cursor-pointer ${
                    index % 2 === 0 ? 'left-0' : 'right-0'
                  }`}
                  style={{
                    top: `${index * 80}px`,
                    transform: index % 2 === 0 ? 'translateX(-20px)' : 'translateX(20px)'
                  }}
                >
                  <feature.icon className="w-8 h-8 text-blue-400 mb-3" />
                  <h3 className="font-bold text-white mb-1">{feature.title}</h3>
                  <p className="text-sm text-gray-300">{feature.desc}</p>
                </motion.div>
              ))}
              
              {/* Central Glow */}
              <div className="absolute inset-0 flex items-center justify-center">
                <motion.div
                  animate={{ 
                    scale: [1, 1.2, 1],
                    rotate: [0, 360]
                  }}
                  transition={{ 
                    duration: 10,
                    repeat: Infinity,
                    ease: "linear"
                  }}
                  className="w-32 h-32 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full blur-3xl opacity-50"
                />
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Stats Section - Overlapping Design */}
      <motion.section
        style={{ y: y2 }}
        className="relative -mt-20 z-10 pb-20"
      >
        <div className="container mx-auto px-6">
          <motion.div
            initial={{ y: 100, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="backdrop-blur-xl bg-gradient-to-r from-white/10 dark:from-white/10 to-white/5 dark:to-white/5 rounded-3xl p-8 border border-gray-200/20 dark:border-white/20"
          >
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                { value: '$2.5B+', label: 'Total Volume' },
                { value: '500K+', label: 'Active Users' },
                { value: '99.9%', label: 'Uptime' },
                { value: '24/7', label: 'Support' }
              ].map((stat, index) => (
                <motion.div
                  key={index}
                  initial={{ scale: 0 }}
                  whileInView={{ scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1, type: "spring" }}
                  className="text-center"
                >
                  <div className="text-3xl lg:text-4xl font-black bg-gradient-to-r from-blue-400 to-purple-600 bg-clip-text text-transparent mb-2">
                    {stat.value}
                  </div>
                  <div className="text-gray-600 dark:text-gray-300 font-medium">{stat.label}</div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </motion.section>

      {/* Interactive Showcase */}
      <section className="py-20 relative">
        <div className="container mx-auto px-6">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl font-black mb-6">
              <span className="bg-gradient-to-r from-teal-500 to-blue-600 bg-clip-text text-transparent">
                Revolutionary
              </span>
              <br />
              <span className="text-gray-900 dark:text-white">Technology</span>
            </h2>
          </motion.div>

          <div className="grid lg:grid-cols-3 gap-8">
            {[
              {
                title: 'Quantum Security',
                desc: 'Next-generation encryption protocols',
                gradient: 'from-blue-500 to-cyan-500'
              },
              {
                title: 'AI Trading',
                desc: 'Machine learning powered strategies',
                gradient: 'from-purple-500 to-pink-500'
              },
              {
                title: 'Cross-Chain',
                desc: 'Seamless multi-blockchain integration',
                gradient: 'from-teal-500 to-green-500'
              }
            ].map((item, index) => (
              <motion.div
                key={index}
                initial={{ y: 100, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.2 }}
                whileHover={{ 
                  y: -10,
                  transition: { type: "spring", stiffness: 300 }
                }}
                className="group relative overflow-hidden rounded-3xl backdrop-blur-xl bg-white/80 dark:bg-white/5 border border-gray-200/20 dark:border-white/10 p-8 cursor-pointer"
              >
                <div className={`absolute inset-0 bg-gradient-to-br ${item.gradient} opacity-0 group-hover:opacity-10 transition-opacity duration-500`}></div>
                <div className="relative z-10">
                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">{item.title}</h3>
                  <p className="text-gray-600 dark:text-gray-300 mb-6">{item.desc}</p>
                  <motion.div
                    whileHover={{ x: 10 }}
                    className="flex items-center text-blue-500 dark:text-blue-400 font-semibold"
                  >
                    Explore <ArrowRight className="ml-2 w-4 h-4" />
                  </motion.div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Token Information Section */}
      <section className="py-32 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-purple-900/20 to-blue-900/20 transform -skew-y-2"></div>
        
        <div className="container mx-auto px-6 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-20"
          >
            <h2 className="text-6xl font-black mb-6">
              <span className="bg-gradient-to-r from-gold-400 to-orange-500 bg-clip-text text-transparent">
                CryptoVerse
              </span>
              <br />
              <span className="text-gray-900 dark:text-white">Token (CVT)</span>
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              Power the future of decentralized education with our native utility token
            </p>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Token Stats */}
            <motion.div
              initial={{ x: -100, opacity: 0 }}
              whileInView={{ x: 0, opacity: 1 }}
              viewport={{ once: true }}
              className="space-y-8"
            >
              <div className="grid grid-cols-2 gap-6">
                {[
                  { label: 'Total Supply', value: '1B CVT', color: 'from-blue-400 to-purple-600' },
                  { label: 'Circulating', value: '250M CVT', color: 'from-purple-400 to-pink-600' },
                  { label: 'Market Cap', value: '$125M', color: 'from-teal-400 to-green-600' },
                  { label: 'Holders', value: '50K+', color: 'from-orange-400 to-red-600' }
                ].map((stat, index) => (
                  <motion.div
                    key={index}
                    initial={{ scale: 0, rotate: -180 }}
                    whileInView={{ scale: 1, rotate: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1, type: "spring" }}
                    whileHover={{ scale: 1.05 }}
                    className="backdrop-blur-xl bg-white/80 dark:bg-white/10 rounded-2xl p-6 border border-gray-200/20 dark:border-white/20 text-center"
                  >
                    <div className={`text-2xl font-bold bg-gradient-to-r ${stat.color} bg-clip-text text-transparent mb-2`}>
                      {stat.value}
                    </div>
                    <div className="text-gray-600 dark:text-gray-300 text-sm">{stat.label}</div>
                  </motion.div>
                ))}
              </div>

              <div className="backdrop-blur-xl bg-white/80 dark:bg-white/10 rounded-3xl p-8 border border-gray-200/20 dark:border-white/20">
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Token Utility</h3>
                <div className="space-y-4">
                  {[
                    'Access premium educational content',
                    'Governance voting rights',
                    'Staking rewards up to 12% APY',
                    'Exclusive community events',
                    'Trading fee discounts'
                  ].map((utility, index) => (
                    <motion.div
                      key={index}
                      initial={{ x: -20, opacity: 0 }}
                      whileInView={{ x: 0, opacity: 1 }}
                      viewport={{ once: true }}
                      transition={{ delay: index * 0.1 }}
                      className="flex items-center space-x-3"
                    >
                      <div className="w-2 h-2 bg-gradient-to-r from-blue-400 to-purple-600 rounded-full"></div>
                      <span className="text-gray-700 dark:text-gray-300">{utility}</span>
                    </motion.div>
                  ))}
                </div>
              </div>
            </motion.div>

            {/* Token Chart Visualization */}
            <motion.div
              initial={{ x: 100, opacity: 0 }}
              whileInView={{ x: 0, opacity: 1 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-3xl blur-3xl"></div>
              <div className="relative backdrop-blur-xl bg-white/80 dark:bg-white/10 rounded-3xl p-8 border border-gray-200/20 dark:border-white/20">
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-6 text-center">Token Distribution</h3>
                <div className="space-y-4">
                  {[
                    { label: 'Community Rewards', percentage: 40, color: 'bg-blue-500' },
                    { label: 'Development', percentage: 25, color: 'bg-purple-500' },
                    { label: 'Marketing', percentage: 15, color: 'bg-teal-500' },
                    { label: 'Team & Advisors', percentage: 12, color: 'bg-orange-500' },
                    { label: 'Reserve Fund', percentage: 8, color: 'bg-pink-500' }
                  ].map((item, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-700 dark:text-gray-300">{item.label}</span>
                        <span className="font-semibold text-gray-900 dark:text-white">{item.percentage}%</span>
                      </div>
                      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                        <motion.div
                          initial={{ width: 0 }}
                          whileInView={{ width: `${item.percentage}%` }}
                          viewport={{ once: true }}
                          transition={{ delay: index * 0.2, duration: 1 }}
                          className={`h-2 rounded-full ${item.color}`}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Case Studies Section */}
      <section className="py-32 relative">
        <div className="container mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-20"
          >
            <h2 className="text-5xl font-black mb-6">
              <span className="bg-gradient-to-r from-teal-500 to-blue-600 bg-clip-text text-transparent">
                Success Stories
              </span>
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              Real-world impact and transformative journeys in Web3
            </p>
          </motion.div>

          <div className="grid lg:grid-cols-3 gap-8">
            {[
              {
                title: 'DeFi Protocol Launch',
                company: 'AquaSwap',
                result: '$50M TVL in 30 days',
                description: 'How our educational platform helped a team launch a successful DeFi protocol',
                image: 'https://images.pexels.com/photos/730547/pexels-photo-730547.jpeg?auto=compress&cs=tinysrgb&w=600',
                gradient: 'from-blue-500 to-cyan-500'
              },
              {
                title: 'NFT Marketplace Success',
                company: 'ArtChain',
                result: '100K+ users',
                description: 'From concept to market leader through comprehensive Web3 education',
                image: 'https://images.pexels.com/photos/7686734/pexels-photo-7686734.jpeg?auto=compress&cs=tinysrgb&w=600',
                gradient: 'from-purple-500 to-pink-500'
              },
              {
                title: 'Enterprise Blockchain',
                company: 'TechCorp',
                result: '40% cost reduction',
                description: 'Corporate blockchain implementation with our training programs',
                image: 'https://images.pexels.com/photos/1181677/pexels-photo-1181677.jpeg?auto=compress&cs=tinysrgb&w=600',
                gradient: 'from-teal-500 to-green-500'
              }
            ].map((study, index) => (
              <motion.div
                key={index}
                initial={{ y: 100, opacity: 0, scale: 0.8 }}
                whileInView={{ y: 0, opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.2, type: "spring" }}
                whileHover={{ y: -20, scale: 1.02 }}
                className="group relative overflow-hidden rounded-3xl backdrop-blur-xl bg-white/80 dark:bg-white/5 border border-gray-200/20 dark:border-white/10 cursor-pointer"
              >
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={study.image} 
                    alt={study.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                  <div className="absolute top-4 right-4">
                    <span className={`px-3 py-1 bg-gradient-to-r ${study.gradient} text-white text-xs font-bold rounded-full`}>
                      CASE STUDY
                    </span>
                  </div>
                </div>
                
                <div className="p-8">
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">{study.title}</h3>
                  <p className="text-gray-600 dark:text-gray-400 text-sm mb-3">{study.company}</p>
                  <div className={`text-2xl font-bold bg-gradient-to-r ${study.gradient} bg-clip-text text-transparent mb-4`}>
                    {study.result}
                  </div>
                  <p className="text-gray-700 dark:text-gray-300 text-sm leading-relaxed">
                    {study.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Blog/News Section */}
      <section className="py-32 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-gray-50/50 to-white/50 dark:from-gray-900/50 dark:to-gray-800/50"></div>
        
        <div className="container mx-auto px-6 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-20"
          >
            <h2 className="text-5xl font-black mb-6">
              <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                Latest Insights
              </span>
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              Stay ahead with the latest Web3 trends, analysis, and educational content
            </p>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-12 mb-16">
            {/* Featured Article */}
            <motion.article
              initial={{ x: -100, opacity: 0 }}
              whileInView={{ x: 0, opacity: 1 }}
              viewport={{ once: true }}
              whileHover={{ scale: 1.02 }}
              className="group relative overflow-hidden rounded-3xl backdrop-blur-xl bg-white/80 dark:bg-white/10 border border-gray-200/20 dark:border-white/20 cursor-pointer"
            >
              <div className="relative h-64 overflow-hidden">
                <img 
                  src="https://images.pexels.com/photos/730547/pexels-photo-730547.jpeg?auto=compress&cs=tinysrgb&w=800" 
                  alt="Featured Article"
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                <div className="absolute top-4 left-4">
                  <span className="px-3 py-1 bg-gradient-to-r from-blue-500 to-purple-600 text-white text-xs font-bold rounded-full">
                    FEATURED
                  </span>
                </div>
                <div className="absolute bottom-4 left-4 right-4">
                  <h3 className="text-2xl font-bold text-white mb-2">
                    The Future of Decentralized Finance: What's Next?
                  </h3>
                  <p className="text-gray-200 text-sm">
                    Exploring the next wave of DeFi innovations and their impact on traditional finance
                  </p>
                </div>
              </div>
              <div className="p-6">
                <div className="flex items-center justify-between text-sm text-gray-500 dark:text-gray-400">
                  <span>Sarah Chen • 5 min read</span>
                  <span>2 days ago</span>
                </div>
              </div>
            </motion.article>

            {/* Article List */}
            <div className="space-y-6">
              {[
                {
                  title: 'Understanding Layer 2 Solutions',
                  excerpt: 'A comprehensive guide to scaling Ethereum',
                  author: 'Alex Rodriguez',
                  time: '3 min read',
                  date: '1 week ago'
                },
                {
                  title: 'NFT Utility Beyond Art',
                  excerpt: 'Real-world applications of non-fungible tokens',
                  author: 'Emma Davis',
                  time: '7 min read',
                  date: '2 weeks ago'
                },
                {
                  title: 'Web3 Security Best Practices',
                  excerpt: 'Protecting your digital assets in DeFi',
                  author: 'David Kim',
                  time: '6 min read',
                  date: '3 weeks ago'
                }
              ].map((article, index) => (
                <motion.article
                  key={index}
                  initial={{ x: 100, opacity: 0 }}
                  whileInView={{ x: 0, opacity: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ x: 10 }}
                  className="group flex items-center space-x-4 p-6 rounded-2xl backdrop-blur-xl bg-white/60 dark:bg-white/5 border border-gray-200/20 dark:border-white/10 cursor-pointer hover:bg-white/80 dark:hover:bg-white/10 transition-all"
                >
                  <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl flex items-center justify-center flex-shrink-0">
                    <span className="text-white font-bold text-lg">{index + 1}</span>
                  </div>
                  <div className="flex-1">
                    <h4 className="font-bold text-gray-900 dark:text-white mb-1 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                      {article.title}
                    </h4>
                    <p className="text-gray-600 dark:text-gray-300 text-sm mb-2">{article.excerpt}</p>
                    <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400">
                      <span>{article.author} • {article.time}</span>
                      <span>{article.date}</span>
                    </div>
                  </div>
                </motion.article>
              ))}
            </div>
          </div>

          <div className="text-center">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-8 py-4 bg-gradient-to-r from-purple-500 to-pink-600 rounded-full font-semibold text-white"
            >
              View All Articles
            </motion.button>
          </div>
        </div>
      </section>

      {/* Educational Resources Section */}
      <section className="py-32 relative">
        <div className="container mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-20"
          >
            <h2 className="text-5xl font-black mb-6">
              <span className="bg-gradient-to-r from-teal-500 to-green-600 bg-clip-text text-transparent">
                Learn & Grow
              </span>
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              Comprehensive educational resources for every level of Web3 expertise
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: '🎓',
                title: 'Beginner Courses',
                count: '25+ Courses',
                description: 'Start your Web3 journey',
                color: 'from-blue-500 to-cyan-500'
              },
              {
                icon: '📚',
                title: 'Advanced Guides',
                count: '50+ Guides',
                description: 'Deep dive into complex topics',
                color: 'from-purple-500 to-pink-500'
              },
              {
                icon: '🎥',
                title: 'Video Tutorials',
                count: '100+ Videos',
                description: 'Visual learning experience',
                color: 'from-teal-500 to-green-500'
              },
              {
                icon: '🛠️',
                title: 'Tools & Resources',
                count: '30+ Tools',
                description: 'Practical Web3 utilities',
                color: 'from-orange-500 to-red-500'
              }
            ].map((resource, index) => (
              <motion.div
                key={index}
                initial={{ y: 100, opacity: 0, scale: 0.8 }}
                whileInView={{ y: 0, opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, type: "spring" }}
                whileHover={{ y: -10, scale: 1.05 }}
                className="group text-center backdrop-blur-xl bg-white/80 dark:bg-white/5 rounded-3xl p-8 border border-gray-200/20 dark:border-white/10 cursor-pointer"
              >
                <div className="text-4xl mb-4">{resource.icon}</div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">{resource.title}</h3>
                <div className={`text-lg font-semibold bg-gradient-to-r ${resource.color} bg-clip-text text-transparent mb-3`}>
                  {resource.count}
                </div>
                <p className="text-gray-600 dark:text-gray-300 text-sm">{resource.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};