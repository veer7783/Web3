import React, { useState, useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { Zap, Shield, TrendingUp, Globe, Cpu, Database, Lock, Smartphone } from 'lucide-react';
import { ParticleBackground } from '../components/ParticleBackground';

export const FeaturesPage: React.FC = () => {
  const [activeFeature, setActiveFeature] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: containerRef });
  
  const rotateX = useTransform(scrollYProgress, [0, 1], [0, 360]);

  const features = [
    {
      icon: Zap,
      title: 'Lightning Speed',
      subtitle: 'Ultra-fast transactions',
      description: 'Process thousands of transactions per second with our advanced blockchain architecture.',
      stats: { value: '50K+', label: 'TPS' },
      color: 'from-yellow-400 to-orange-500',
      bgColor: 'from-yellow-500/20 to-orange-500/20'
    },
    {
      icon: Shield,
      title: 'Military-Grade Security',
      subtitle: 'Unbreakable protection',
      description: 'Multi-layered security protocols with quantum-resistant encryption.',
      stats: { value: '99.99%', label: 'Uptime' },
      color: 'from-green-400 to-teal-500',
      bgColor: 'from-green-500/20 to-teal-500/20'
    },
    {
      icon: TrendingUp,
      title: 'AI-Powered Analytics',
      subtitle: 'Smart insights',
      description: 'Machine learning algorithms provide real-time market analysis and predictions.',
      stats: { value: '95%', label: 'Accuracy' },
      color: 'from-purple-400 to-pink-500',
      bgColor: 'from-purple-500/20 to-pink-500/20'
    },
    {
      icon: Globe,
      title: 'Global Accessibility',
      subtitle: 'Worldwide reach',
      description: 'Available in 150+ countries with local currency support.',
      stats: { value: '150+', label: 'Countries' },
      color: 'from-blue-400 to-cyan-500',
      bgColor: 'from-blue-500/20 to-cyan-500/20'
    },
    {
      icon: Cpu,
      title: 'Advanced Technology',
      subtitle: 'Cutting-edge infrastructure',
      description: 'Built on next-generation blockchain with smart contract capabilities.',
      stats: { value: '1M+', label: 'Smart Contracts' },
      color: 'from-indigo-400 to-purple-500',
      bgColor: 'from-indigo-500/20 to-purple-500/20'
    },
    {
      icon: Database,
      title: 'Scalable Architecture',
      subtitle: 'Infinite possibilities',
      description: 'Horizontally scalable infrastructure that grows with your needs.',
      stats: { value: '∞', label: 'Scalability' },
      color: 'from-teal-400 to-green-500',
      bgColor: 'from-teal-500/20 to-green-500/20'
    }
  ];

  const techSpecs = [
    { label: 'Consensus Algorithm', value: 'Proof of Stake 2.0' },
    { label: 'Block Time', value: '2 seconds' },
    { label: 'Energy Efficiency', value: '99.9% less than Bitcoin' },
    { label: 'Cross-Chain Support', value: '20+ blockchains' }
  ];

  return (
    <div ref={containerRef} className="relative min-h-screen">
      <ParticleBackground density={100} colors={['#3b82f6', '#8b5cf6', '#14b8a6', '#f59e0b']} />
      
      {/* Hero Section - 3D Perspective */}
      <section className="relative min-h-screen flex items-center overflow-hidden pt-20 bg-gray-900 dark:bg-gray-900">
        <div className="container mx-auto px-6">
          <div className="text-center mb-20">
            <motion.h1
              initial={{ y: 100, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 1 }}
              className="text-7xl lg:text-9xl font-black mb-8"
            >
              <span className="bg-gradient-to-r from-blue-400 via-purple-500 to-teal-400 bg-clip-text text-transparent">
                Features
              </span>
            </motion.h1>
            
            <motion.p
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.3, duration: 0.8 }}
              className="text-gray-200 dark:text-gray-300 max-w-3xl mx-auto"
            >
              Revolutionary technology that powers the future of decentralized finance
            </motion.p>
          </div>

          {/* Interactive Feature Showcase */}
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Feature List */}
            <div className="space-y-4">
              {features.map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ x: -100, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: index * 0.1 }}
                  onClick={() => setActiveFeature(index)}
                  className={`cursor-pointer p-6 rounded-2xl border transition-all duration-300 ${
                    activeFeature === index
                      ? 'bg-white/10 border-white/30 backdrop-blur-xl'
                      : 'bg-white/5 border-white/10 hover:bg-white/8'
                  }`}
                >
                  <div className="flex items-center space-x-4">
                    <motion.div
                      whileHover={{ rotate: 360 }}
                      transition={{ duration: 0.6 }}
                      className={`w-12 h-12 rounded-xl bg-gradient-to-r ${feature.color} flex items-center justify-center`}
                    >
                      <feature.icon className="w-6 h-6 text-white" />
                    </motion.div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-white">{feature.title}</h3>
                      <p className="text-gray-400">{feature.subtitle}</p>
                    </div>
                    <div className="text-right">
                      <div className={`text-2xl font-bold bg-gradient-to-r ${feature.color} bg-clip-text text-transparent`}>
                        {feature.stats.value}
                      </div>
                      <div className="text-sm text-gray-400">{feature.stats.label}</div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Active Feature Display */}
            <motion.div
              key={activeFeature}
              initial={{ scale: 0.8, opacity: 0, rotateY: -90 }}
              animate={{ scale: 1, opacity: 1, rotateY: 0 }}
              transition={{ type: "spring", stiffness: 100 }}
              className="relative"
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${features[activeFeature].bgColor} rounded-3xl blur-3xl`}></div>
              <div className="relative backdrop-blur-xl bg-white/10 rounded-3xl p-12 border border-white/20">
               {(() => {
                 const IconComponent = features[activeFeature].icon;
                 return (
                <motion.div
                  style={{ rotateX }}
                  className={`w-24 h-24 rounded-2xl bg-gradient-to-r ${features[activeFeature].color} flex items-center justify-center mb-8 mx-auto`}
                >
                 <IconComponent className="w-12 h-12 text-white" />
                </motion.div>
                 );
               })()}
                
                <h2 className="text-3xl font-bold text-white mb-4 text-center">
                  {features[activeFeature].title}
                </h2>
                
                <p className="text-gray-300 text-lg leading-relaxed text-center">
                  {features[activeFeature].description}
                </p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Technical Specifications - Floating Cards */}
      <section className="py-32 relative">
        <div className="container mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-20"
          >
            <h2 className="text-5xl font-black mb-6">
              <span className="bg-gradient-to-r from-teal-400 to-blue-600 bg-clip-text text-transparent">
                Technical Excellence
              </span>
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {techSpecs.map((spec, index) => (
              <motion.div
                key={index}
                initial={{ y: 100, opacity: 0, rotateX: -90 }}
                whileInView={{ y: 0, opacity: 1, rotateX: 0 }}
                viewport={{ once: true }}
                transition={{ 
                  delay: index * 0.1,
                  type: "spring",
                  stiffness: 100
                }}
                whileHover={{ 
                  y: -20,
                  rotateY: 10,
                  transition: { type: "spring", stiffness: 300 }
                }}
                className="group relative overflow-hidden rounded-3xl backdrop-blur-xl bg-white/5 border border-white/10 p-8 text-center"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-purple-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                
                <div className="relative z-10">
                  <div className="text-sm text-gray-400 mb-2 uppercase tracking-wider">
                    {spec.label}
                  </div>
                  <div className="text-2xl font-bold text-white">
                    {spec.value}
                  </div>
                </div>

                {/* Animated Border */}
                <motion.div
                  initial={{ pathLength: 0 }}
                  whileInView={{ pathLength: 1 }}
                  transition={{ duration: 2, delay: index * 0.2 }}
                  className="absolute inset-0 rounded-3xl"
                  style={{
                    background: `conic-gradient(from 0deg, transparent, #3b82f6, transparent)`,
                    padding: '1px',
                    mask: 'linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)',
                    maskComposite: 'exclude'
                  }}
                />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Interactive Demo Section */}
      <section className="py-32 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-purple-900/20 to-blue-900/20 transform skew-y-3"></div>
        
        <div className="container mx-auto px-6 relative z-10">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="max-w-4xl mx-auto text-center"
          >
            <h2 className="text-6xl font-black mb-8">
              <span className="bg-gradient-to-r from-gold-400 to-orange-500 bg-clip-text text-transparent">
                Experience
              </span>
              <br />
              <span className="text-white">The Future</span>
            </h2>
            
            <p className="text-xl text-gray-300 mb-12">
              Ready to revolutionize your financial journey?
            </p>

            <div className="flex flex-col sm:flex-row gap-6 justify-center">
              <motion.button
                whileHover={{ scale: 1.05, boxShadow: "0 20px 40px rgba(59, 130, 246, 0.3)" }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-4 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full font-semibold text-white text-lg"
              >
                Start Free Trial
              </motion.button>
              
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-4 border-2 border-teal-500 text-teal-400 rounded-full font-semibold text-lg hover:bg-teal-500 hover:text-white transition-all"
              >
                View Documentation
              </motion.button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};