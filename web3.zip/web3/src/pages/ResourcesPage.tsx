import React, { useState, useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { BookOpen, Video, FileText, Download, Search, Filter, Clock, User, Star } from 'lucide-react';
import { ParticleBackground } from '../components/ParticleBackground';

export const ResourcesPage: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: containerRef });
  
  const y = useTransform(scrollYProgress, [0, 1], ['0%', '50%']);

  const categories = [
    { id: 'all', label: 'All Resources', count: 156 },
    { id: 'guides', label: 'Guides', count: 45 },
    { id: 'tutorials', label: 'Tutorials', count: 38 },
    { id: 'articles', label: 'Articles', count: 52 },
    { id: 'videos', label: 'Videos', count: 21 }
  ];

  const resources = [
    {
      id: 1,
      type: 'guide',
      title: 'Complete DeFi Beginner\'s Guide',
      excerpt: 'Everything you need to know about decentralized finance, from basic concepts to advanced strategies.',
      author: 'Sarah Chen',
      readTime: '15 min read',
      rating: 4.9,
      image: 'https://images.pexels.com/photos/730547/pexels-photo-730547.jpeg?auto=compress&cs=tinysrgb&w=600',
      category: 'guides',
      featured: true
    },
    {
      id: 2,
      type: 'video',
      title: 'Smart Contract Development Masterclass',
      excerpt: 'Learn to build and deploy smart contracts on Ethereum with real-world examples.',
      author: 'Alex Rodriguez',
      readTime: '2 hr watch',
      rating: 4.8,
      image: 'https://images.pexels.com/photos/577585/pexels-photo-577585.jpeg?auto=compress&cs=tinysrgb&w=600',
      category: 'tutorials'
    },
    {
      id: 3,
      type: 'article',
      title: 'The Future of Cross-Chain Interoperability',
      excerpt: 'Exploring the technologies that will connect different blockchain networks.',
      author: 'Maria Santos',
      readTime: '8 min read',
      rating: 4.7,
      image: 'https://images.pexels.com/photos/1181677/pexels-photo-1181677.jpeg?auto=compress&cs=tinysrgb&w=600',
      category: 'articles'
    },
    {
      id: 4,
      type: 'guide',
      title: 'NFT Trading Strategies',
      excerpt: 'Advanced techniques for evaluating and trading non-fungible tokens profitably.',
      author: 'David Kim',
      readTime: '12 min read',
      rating: 4.6,
      image: 'https://images.pexels.com/photos/7686734/pexels-photo-7686734.jpeg?auto=compress&cs=tinysrgb&w=600',
      category: 'guides'
    },
    {
      id: 5,
      type: 'tutorial',
      title: 'Building Your First dApp',
      excerpt: 'Step-by-step tutorial for creating a decentralized application from scratch.',
      author: 'Emma Wilson',
      readTime: '45 min tutorial',
      rating: 4.9,
      image: 'https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg?auto=compress&cs=tinysrgb&w=600',
      category: 'tutorials',
      featured: true
    },
    {
      id: 6,
      type: 'article',
      title: 'Crypto Security Best Practices',
      excerpt: 'Essential security measures every crypto investor should implement.',
      author: 'John Thompson',
      readTime: '10 min read',
      rating: 4.8,
      image: 'https://images.pexels.com/photos/60504/security-protection-anti-virus-software-60504.jpeg?auto=compress&cs=tinysrgb&w=600',
      category: 'articles'
    }
  ];

  const filteredResources = resources.filter(resource => {
    const matchesCategory = activeCategory === 'all' || resource.category === activeCategory;
    const matchesSearch = resource.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         resource.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'video': return Video;
      case 'guide': return BookOpen;
      case 'tutorial': return FileText;
      default: return FileText;
    }
  };

  return (
    <div ref={containerRef} className="relative min-h-screen">
      <ParticleBackground density={70} colors={['#3b82f6', '#8b5cf6', '#14b8a6']} />
      
      {/* Hero Section - Asymmetric Layout */}
      <section className="relative min-h-screen flex items-center overflow-hidden pt-20 bg-gray-900 dark:bg-gray-900">
        <motion.div
          style={{ y }}
          className="absolute inset-0 bg-gradient-to-br from-blue-900/30 via-purple-900/30 to-teal-900/30"
        />
        
        <div className="container mx-auto px-6 relative z-10">
          <div className="grid lg:grid-cols-5 gap-12 items-center">
            {/* Left Content */}
            <motion.div
              initial={{ x: -100, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ duration: 1 }}
              className="lg:col-span-3 space-y-8"
            >
              <motion.h1
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.2 }}
                className="text-6xl lg:text-8xl font-black leading-none"
              >
                <span className="bg-gradient-to-r from-blue-400 to-purple-600 bg-clip-text text-transparent">
                  Learn
                </span>
                <br />
                <span className="text-white dark:text-white">Everything</span>
              </motion.h1>
              
              <motion.p
                initial={{ y: 30, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.4 }}
                className="text-xl text-gray-200 dark:text-gray-300 leading-relaxed max-w-2xl"
              >
                Comprehensive resources, tutorials, and guides to master Web3 and cryptocurrency. 
                From beginner basics to advanced strategies.
              </motion.p>

              {/* Search Bar */}
              <motion.div
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.6 }}
                className="relative max-w-md"
              >
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search resources..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-12 pr-4 py-4 rounded-2xl backdrop-blur-xl bg-white/10 border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                />
              </motion.div>
            </motion.div>

            {/* Right Stats */}
            <motion.div
              initial={{ x: 100, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ duration: 1, delay: 0.3 }}
              className="lg:col-span-2 space-y-6"
            >
              {[
                { number: '156+', label: 'Resources', color: 'from-blue-400 to-cyan-500' },
                { number: '50K+', label: 'Students', color: 'from-purple-400 to-pink-500' },
                { number: '4.8★', label: 'Average Rating', color: 'from-yellow-400 to-orange-500' },
                { number: '24/7', label: 'Support', color: 'from-teal-400 to-green-500' }
              ].map((stat, index) => (
                <motion.div
                  key={index}
                  initial={{ scale: 0, rotate: -180 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{ delay: 0.8 + index * 0.1, type: "spring" }}
                  whileHover={{ scale: 1.05, rotate: 5 }}
                  className="backdrop-blur-xl bg-white/10 rounded-2xl p-6 border border-white/20"
                >
                  <div className={`text-3xl font-black bg-gradient-to-r ${stat.color} bg-clip-text text-transparent mb-2`}>
                    {stat.number}
                  </div>
                  <div className="text-gray-300 font-medium">{stat.label}</div>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* Category Filter - Floating Navigation */}
      <section className="relative -mt-20 z-20">
        <div className="container mx-auto px-6">
          <motion.div
            initial={{ y: 100, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            className="backdrop-blur-xl bg-white/10 rounded-3xl p-6 border border-white/20"
          >
            <div className="flex flex-wrap gap-4 justify-center">
              {categories.map((category) => (
                <motion.button
                  key={category.id}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setActiveCategory(category.id)}
                  className={`px-6 py-3 rounded-full font-semibold transition-all ${
                    activeCategory === category.id
                      ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white'
                      : 'bg-white/10 text-gray-300 hover:bg-white/20'
                  }`}
                >
                  {category.label}
                  <span className="ml-2 text-sm opacity-75">({category.count})</span>
                </motion.button>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Resources Grid - Masonry Layout */}
      <section className="py-20">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredResources.map((resource, index) => {
              const TypeIcon = getTypeIcon(resource.type);
              
              return (
                <motion.article
                  key={resource.id}
                  initial={{ y: 100, opacity: 0, scale: 0.8 }}
                  whileInView={{ y: 0, opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1, type: "spring" }}
                  whileHover={{ 
                    y: -20,
                    rotateY: 5,
                    transition: { type: "spring", stiffness: 300 }
                  }}
                  className={`group relative overflow-hidden rounded-3xl backdrop-blur-xl bg-white/5 border border-white/10 cursor-pointer ${
                    resource.featured ? 'lg:row-span-2' : ''
                  } ${index % 3 === 1 ? 'lg:mt-12' : ''}`}
                >
                  {/* Featured Badge */}
                  {resource.featured && (
                    <div className="absolute top-4 left-4 z-10">
                      <span className="px-3 py-1 bg-gradient-to-r from-yellow-400 to-orange-500 text-black text-xs font-bold rounded-full">
                        FEATURED
                      </span>
                    </div>
                  )}

                  {/* Image */}
                  <div className="relative h-48 overflow-hidden">
                    <img 
                      src={resource.image} 
                      alt={resource.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                    
                    {/* Type Icon */}
                    <div className="absolute top-4 right-4">
                      <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                        <TypeIcon className="w-5 h-5 text-white" />
                      </div>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-6 space-y-4">
                    <div className="flex items-center justify-between text-sm text-gray-400">
                      <div className="flex items-center space-x-1">
                        <User className="w-4 h-4" />
                        <span>{resource.author}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock className="w-4 h-4" />
                        <span>{resource.readTime}</span>
                      </div>
                    </div>

                    <h3 className="text-xl font-bold text-white group-hover:text-blue-400 transition-colors line-clamp-2">
                      {resource.title}
                    </h3>

                    <p className="text-gray-300 line-clamp-3 leading-relaxed">
                      {resource.excerpt}
                    </p>

                    <div className="flex items-center justify-between pt-4 border-t border-white/10">
                      <div className="flex items-center space-x-1">
                        <Star className="w-4 h-4 text-yellow-400 fill-current" />
                        <span className="text-sm text-gray-300">{resource.rating}</span>
                      </div>
                      
                      <motion.button
                        whileHover={{ x: 5 }}
                        className="flex items-center text-blue-400 font-semibold text-sm"
                      >
                        Read More
                        <Download className="ml-1 w-4 h-4" />
                      </motion.button>
                    </div>
                  </div>

                  {/* Hover Effect */}
                  <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-purple-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                </motion.article>
              );
            })}
          </div>

          {/* Load More */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mt-16"
          >
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-8 py-4 bg-gradient-to-r from-teal-500 to-blue-600 rounded-full font-semibold text-white"
            >
              Load More Resources
            </motion.button>
          </motion.div>
        </div>
      </section>
    </div>
  );
};