import React, { useRef } from 'react';
import { motion, useScroll, useTransform, useInView } from 'framer-motion';
import { Target, Users, Lightbulb, Rocket, Globe, Shield } from 'lucide-react';
import { ParticleBackground } from '../components/ParticleBackground';

export const AboutPage: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: containerRef });
  
  const backgroundY = useTransform(scrollYProgress, [0, 1], ['0%', '100%']);
  const textY = useTransform(scrollYProgress, [0, 1], ['0%', '50%']);

  const values = [
    {
      icon: Target,
      title: 'Our Mission',
      description: 'Democratizing access to decentralized finance through innovative technology and education.',
      color: 'from-blue-500 to-cyan-500'
    },
    {
      icon: Users,
      title: 'Community First',
      description: 'Building a global ecosystem where every voice matters and every contribution counts.',
      color: 'from-purple-500 to-pink-500'
    },
    {
      icon: Lightbulb,
      title: 'Innovation',
      description: 'Pushing the boundaries of what\'s possible in blockchain and cryptocurrency.',
      color: 'from-teal-500 to-green-500'
    },
    {
      icon: Rocket,
      title: 'Growth',
      description: 'Accelerating the adoption of Web3 technologies across all industries.',
      color: 'from-orange-500 to-red-500'
    },
    {
      icon: Globe,
      title: 'Global Impact',
      description: 'Creating positive change in financial systems worldwide.',
      color: 'from-indigo-500 to-purple-500'
    },
    {
      icon: Shield,
      title: 'Security',
      description: 'Maintaining the highest standards of security and trust in everything we do.',
      color: 'from-green-500 to-teal-500'
    }
  ];

  return (
    <div ref={containerRef} className="relative min-h-screen">
      <ParticleBackground density={60} colors={['#3b82f6', '#8b5cf6', '#14b8a6', '#f59e0b']} />
      
      {/* Hero Section with Diagonal Layout */}
      <section className="relative min-h-screen flex items-center overflow-hidden pt-20 bg-gray-900 dark:bg-gray-900">
        <motion.div
          style={{ y: backgroundY }}
          className="absolute inset-0 bg-gradient-to-br from-blue-900/30 via-purple-900/30 to-teal-900/30"
        />
        
        <div className="container mx-auto px-6 relative z-10">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ x: -100, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ duration: 1 }}
              className="space-y-8"
            >
              <motion.h1
                style={{ y: textY }}
                className="text-6xl lg:text-8xl font-black leading-none"
              >
                <span className="bg-gradient-to-r from-blue-400 to-purple-600 bg-clip-text text-transparent">
                  Shaping
                </span>
                <br />
                <span className="text-white dark:text-white">Tomorrow</span>
              </motion.h1>
              
              <motion.p
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.3, duration: 0.8 }}
                className="text-xl text-gray-300 leading-relaxed max-w-lg"
              >
                We're not just building a platform – we're architecting the future of decentralized finance, 
                one innovation at a time.
              </motion.p>
            </motion.div>

            {/* Floating Timeline */}
            <motion.div
              initial={{ x: 100, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ duration: 1, delay: 0.2 }}
              className="relative"
            >
              <div className="space-y-8">
                {[
                  { year: '2019', event: 'Founded with a vision' },
                  { year: '2021', event: 'First blockchain integration' },
                  { year: '2023', event: 'Multi-chain expansion' },
                  { year: '2024', event: 'AI-powered features' },
                  { year: '2025', event: 'Global adoption' }
                ].map((item, index) => (
                  <motion.div
                    key={index}
                    initial={{ x: 50, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: 0.5 + index * 0.1 }}
                    whileHover={{ x: 10, scale: 1.05 }}
                    className="flex items-center space-x-6 backdrop-blur-xl bg-white/10 rounded-2xl p-6 border border-white/20"
                  >
                    <div className="text-2xl font-bold text-blue-400">{item.year}</div>
                    <div className="text-white font-medium">{item.event}</div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Values Grid - Masonry Style */}
      <section className="py-32 relative">
        <div className="container mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-20"
          >
            <h2 className="text-5xl font-black mb-6">
              <span className="bg-gradient-to-r from-teal-400 to-purple-600 bg-clip-text text-transparent">
                Our Values
              </span>
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              The principles that guide everything we do
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {values.map((value, index) => (
              <motion.div
                key={index}
                initial={{ y: 100, opacity: 0, scale: 0.8 }}
                whileInView={{ y: 0, opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ 
                  delay: index * 0.1,
                  type: "spring",
                  stiffness: 100
                }}
                whileHover={{ 
                  y: -20,
                  rotateY: 5,
                  transition: { type: "spring", stiffness: 300 }
                }}
                className={`group relative overflow-hidden rounded-3xl backdrop-blur-xl bg-white/5 border border-white/10 p-8 cursor-pointer ${
                  index % 3 === 1 ? 'lg:mt-12' : ''
                } ${index % 3 === 2 ? 'lg:mt-24' : ''}`}
              >
                <div className={`absolute inset-0 bg-gradient-to-br ${value.color} opacity-0 group-hover:opacity-10 transition-opacity duration-500`}></div>
                
                <div className="relative z-10">
                  <motion.div
                    whileHover={{ rotate: 360, scale: 1.2 }}
                    transition={{ duration: 0.6 }}
                    className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${value.color} flex items-center justify-center mb-6`}
                  >
                    <value.icon className="w-8 h-8 text-white" />
                  </motion.div>
                  
                  <h3 className="text-2xl font-bold text-white mb-4">{value.title}</h3>
                  <p className="text-gray-300 leading-relaxed">{value.description}</p>
                </div>

                {/* Hover Effect */}
                <motion.div
                  initial={{ scale: 0, opacity: 0 }}
                  whileHover={{ scale: 1, opacity: 1 }}
                  className="absolute top-4 right-4 w-3 h-3 bg-blue-400 rounded-full"
                />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Vision Statement - Diagonal Split */}
      <section className="relative py-32 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900/30 to-purple-900/30 transform -skew-y-3"></div>
        
        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="space-y-8"
            >
              <h2 className="text-6xl font-black">
                <span className="bg-gradient-to-r from-gold-400 to-orange-500 bg-clip-text text-transparent">
                  The Future
                </span>
                <br />
                <span className="text-white">We're Building</span>
              </h2>
              
              <motion.p
                initial={{ y: 30, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.3 }}
                className="text-2xl text-gray-300 leading-relaxed"
              >
                A world where financial freedom isn't a privilege, but a fundamental right. 
                Where technology serves humanity, and innovation creates opportunity for all.
              </motion.p>

              <motion.div
                initial={{ y: 50, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.5 }}
                className="grid md:grid-cols-3 gap-8 mt-16"
              >
                {[
                  { number: '1M+', label: 'Lives Changed' },
                  { number: '150+', label: 'Countries Reached' },
                  { number: '∞', label: 'Possibilities Ahead' }
                ].map((stat, index) => (
                  <motion.div
                    key={index}
                    whileHover={{ scale: 1.1 }}
                    className="backdrop-blur-xl bg-white/10 rounded-2xl p-8 border border-white/20"
                  >
                    <div className="text-4xl font-black bg-gradient-to-r from-blue-400 to-purple-600 bg-clip-text text-transparent mb-2">
                      {stat.number}
                    </div>
                    <div className="text-gray-300 font-medium">{stat.label}</div>
                  </motion.div>
                ))}
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  );
};