import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Twitter, Linkedin, Github, Mail, MapPin, Calendar, Award } from 'lucide-react';
import { ParticleBackground } from '../components/ParticleBackground';

export const TeamPage: React.FC = () => {
  const [selectedMember, setSelectedMember] = useState<number | null>(null);

  const teamMembers = [
    {
      id: 1,
      name: 'Sarah Chen',
      role: 'CEO & Co-Founder',
      bio: 'Former Goldman Sachs VP with 12+ years in fintech. Led blockchain initiatives at major banks.',
      image: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=400',
      location: 'San Francisco, CA',
      joined: '2019',
      achievements: ['Forbes 30 Under 30', 'Blockchain Innovation Award', 'TEDx Speaker'],
      socials: { twitter: '#', linkedin: '#', github: '#', email: 'sarah@cryptoverse.com' },
      gradient: 'from-blue-500 to-purple-600',
      specialty: 'Strategic Leadership'
    },
    {
      id: 2,
      name: 'Marcus Rodriguez',
      role: 'CTO & Co-Founder',
      bio: 'Former Google engineer specializing in distributed systems and blockchain architecture.',
      image: 'https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg?auto=compress&cs=tinysrgb&w=400',
      location: 'Austin, TX',
      joined: '2019',
      achievements: ['MIT Technology Review Innovator', 'Open Source Contributor', 'Patent Holder'],
      socials: { twitter: '#', linkedin: '#', github: '#', email: 'marcus@cryptoverse.com' },
      gradient: 'from-purple-500 to-pink-600',
      specialty: 'Blockchain Architecture'
    },
    {
      id: 3,
      name: 'Elena Volkov',
      role: 'Head of Research',
      bio: 'PhD in Cryptography from Stanford. Leading research in zero-knowledge proofs and privacy.',
      image: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=400',
      location: 'Palo Alto, CA',
      joined: '2020',
      achievements: ['Cryptography Research Award', 'Published 50+ Papers', 'Conference Speaker'],
      socials: { twitter: '#', linkedin: '#', github: '#', email: 'elena@cryptoverse.com' },
      gradient: 'from-teal-500 to-green-600',
      specialty: 'Cryptographic Research'
    },
    {
      id: 4,
      name: 'David Kim',
      role: 'Head of Product',
      bio: 'Former Coinbase product lead. Expert in user experience and product strategy for crypto.',
      image: 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=400',
      location: 'New York, NY',
      joined: '2020',
      achievements: ['Product Excellence Award', 'UX Design Recognition', 'Industry Speaker'],
      socials: { twitter: '#', linkedin: '#', github: '#', email: 'david@cryptoverse.com' },
      gradient: 'from-orange-500 to-red-600',
      specialty: 'Product Strategy'
    },
    {
      id: 5,
      name: 'Aisha Patel',
      role: 'Head of Security',
      bio: 'Cybersecurity expert with focus on blockchain security and smart contract auditing.',
      image: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=400',
      location: 'London, UK',
      joined: '2021',
      achievements: ['Security Excellence Award', 'Bug Bounty Hunter', 'Security Researcher'],
      socials: { twitter: '#', linkedin: '#', github: '#', email: 'aisha@cryptoverse.com' },
      gradient: 'from-indigo-500 to-blue-600',
      specialty: 'Security & Auditing'
    },
    {
      id: 6,
      name: 'James Wilson',
      role: 'Head of Marketing',
      bio: 'Growth marketing expert who scaled multiple fintech startups from seed to IPO.',
      image: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=400',
      location: 'Miami, FL',
      joined: '2021',
      achievements: ['Marketing Innovation Award', 'Growth Hacker of the Year', 'Brand Builder'],
      socials: { twitter: '#', linkedin: '#', github: '#', email: 'james@cryptoverse.com' },
      gradient: 'from-yellow-500 to-orange-600',
      specialty: 'Growth & Marketing'
    }
  ];

  const advisors = [
    {
      name: 'Dr. Vitalik Buterin',
      role: 'Strategic Advisor',
      company: 'Ethereum Foundation',
      image: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=300'
    },
    {
      name: 'Changpeng Zhao',
      role: 'Industry Advisor',
      company: 'Former Binance CEO',
      image: 'https://images.pexels.com/photos/1181690/pexels-photo-1181690.jpeg?auto=compress&cs=tinysrgb&w=300'
    },
    {
      name: 'Cathie Wood',
      role: 'Investment Advisor',
      company: 'ARK Invest',
      image: 'https://images.pexels.com/photos/1181695/pexels-photo-1181695.jpeg?auto=compress&cs=tinysrgb&w=300'
    }
  ];

  return (
    <div className="relative min-h-screen">
      <ParticleBackground density={60} colors={['#3b82f6', '#8b5cf6', '#14b8a6', '#f59e0b']} />
      
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center overflow-hidden pt-20 bg-gray-900 dark:bg-gray-900">
        <div className="container mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
            className="text-center mb-20"
          >
            <h1 className="text-7xl lg:text-9xl font-black mb-8">
              <span className="bg-gradient-to-r from-blue-400 via-purple-500 to-teal-400 bg-clip-text text-transparent">
                Our Team
              </span>
            </h1>
            <p className="text-2xl text-gray-200 dark:text-gray-300 max-w-3xl mx-auto">
              Meet the visionaries building the future of decentralized finance
            </p>
          </motion.div>

          {/* Team Grid - Hexagonal Layout */}
          <div className="relative max-w-6xl mx-auto">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {teamMembers.map((member, index) => (
                <motion.div
                  key={member.id}
                  initial={{ scale: 0, rotate: -180, opacity: 0 }}
                  animate={{ scale: 1, rotate: 0, opacity: 1 }}
                  transition={{ 
                    delay: index * 0.1,
                    type: "spring",
                    stiffness: 100
                  }}
                  whileHover={{ 
                    scale: 1.05,
                    rotateY: 10,
                    transition: { type: "spring", stiffness: 300 }
                  }}
                  onClick={() => setSelectedMember(member.id)}
                  className={`group relative overflow-hidden rounded-3xl backdrop-blur-xl bg-white/5 border border-white/10 p-8 cursor-pointer ${
                    index % 3 === 1 ? 'lg:mt-12' : ''
                  } ${index % 3 === 2 ? 'lg:mt-24' : ''}`}
                >
                  {/* Background Gradient */}
                  <div className={`absolute inset-0 bg-gradient-to-br ${member.gradient} opacity-0 group-hover:opacity-10 transition-opacity duration-500`}></div>
                  
                  {/* Profile Image */}
                  <div className="relative mb-6">
                    <div className={`absolute inset-0 bg-gradient-to-r ${member.gradient} rounded-full blur-xl opacity-50 group-hover:opacity-75 transition-opacity`}></div>
                    <img 
                      src={member.image} 
                      alt={member.name}
                      className="relative w-24 h-24 rounded-full mx-auto object-cover border-4 border-white/20 group-hover:scale-110 transition-transform duration-300"
                    />
                  </div>
                  
                  {/* Content */}
                  <div className="relative z-10 text-center">
                    <h3 className="text-xl font-bold text-white mb-2">{member.name}</h3>
                    <p className={`text-sm font-semibold bg-gradient-to-r ${member.gradient} bg-clip-text text-transparent mb-3`}>
                      {member.role}
                    </p>
                    <p className="text-gray-300 text-sm leading-relaxed mb-4 line-clamp-3">
                      {member.bio}
                    </p>
                    
                    {/* Quick Info */}
                    <div className="flex items-center justify-center space-x-4 text-xs text-gray-400 mb-4">
                      <div className="flex items-center space-x-1">
                        <MapPin className="w-3 h-3" />
                        <span>{member.location}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Calendar className="w-3 h-3" />
                        <span>Since {member.joined}</span>
                      </div>
                    </div>

                    {/* Social Links */}
                    <div className="flex justify-center space-x-3">
                      <motion.a 
                        whileHover={{ scale: 1.2, rotate: 360 }}
                        href={member.socials.twitter}
                        className="p-2 rounded-full bg-white/10 hover:bg-blue-500 transition-colors"
                      >
                        <Twitter className="w-4 h-4" />
                      </motion.a>
                      <motion.a 
                        whileHover={{ scale: 1.2, rotate: 360 }}
                        href={member.socials.linkedin}
                        className="p-2 rounded-full bg-white/10 hover:bg-blue-600 transition-colors"
                      >
                        <Linkedin className="w-4 h-4" />
                      </motion.a>
                      <motion.a 
                        whileHover={{ scale: 1.2, rotate: 360 }}
                        href={member.socials.github}
                        className="p-2 rounded-full bg-white/10 hover:bg-gray-800 transition-colors"
                      >
                        <Github className="w-4 h-4" />
                      </motion.a>
                    </div>
                  </div>

                  {/* Hover Indicator */}
                  <motion.div
                    initial={{ scale: 0 }}
                    whileHover={{ scale: 1 }}
                    className="absolute top-4 right-4 w-3 h-3 bg-blue-400 rounded-full"
                  />
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Advisors Section */}
      <section className="py-32 relative">
        <div className="container mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl font-black mb-6">
              <span className="bg-gradient-to-r from-teal-400 to-purple-600 bg-clip-text text-transparent">
                Advisory Board
              </span>
            </h2>
            <p className="text-xl text-gray-300">
              Industry leaders guiding our vision
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            {advisors.map((advisor, index) => (
              <motion.div
                key={index}
                initial={{ y: 100, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.2 }}
                whileHover={{ y: -10, scale: 1.05 }}
                className="backdrop-blur-xl bg-white/10 rounded-2xl p-6 border border-white/20 text-center"
              >
                <img 
                  src={advisor.image} 
                  alt={advisor.name}
                  className="w-20 h-20 rounded-full mx-auto mb-4 object-cover"
                />
                <h3 className="text-lg font-bold text-white mb-1">{advisor.name}</h3>
                <p className="text-blue-400 font-semibold text-sm mb-1">{advisor.role}</p>
                <p className="text-gray-400 text-sm">{advisor.company}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Member Detail Modal */}
      <AnimatePresence>
        {selectedMember && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-6"
            onClick={() => setSelectedMember(null)}
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0, rotateY: -90 }}
              animate={{ scale: 1, opacity: 1, rotateY: 0 }}
              exit={{ scale: 0.8, opacity: 0, rotateY: 90 }}
              onClick={(e) => e.stopPropagation()}
              className="max-w-2xl w-full backdrop-blur-xl bg-white/10 rounded-3xl p-8 border border-white/20"
            >
              {(() => {
                const member = teamMembers.find(m => m.id === selectedMember);
                if (!member) return null;
                
                return (
                  <div className="text-center">
                    <img 
                      src={member.image} 
                      alt={member.name}
                      className="w-32 h-32 rounded-full mx-auto mb-6 object-cover"
                    />
                    <h2 className="text-3xl font-bold text-white mb-2">{member.name}</h2>
                    <p className={`text-lg font-semibold bg-gradient-to-r ${member.gradient} bg-clip-text text-transparent mb-4`}>
                      {member.role}
                    </p>
                    <p className="text-gray-300 leading-relaxed mb-6">{member.bio}</p>
                    
                    <div className="grid md:grid-cols-2 gap-6 mb-6">
                      <div>
                        <h4 className="text-white font-semibold mb-2 flex items-center justify-center">
                          <Award className="w-4 h-4 mr-2" />
                          Achievements
                        </h4>
                        <ul className="text-gray-300 text-sm space-y-1">
                          {member.achievements.map((achievement, i) => (
                            <li key={i}>• {achievement}</li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <h4 className="text-white font-semibold mb-2">Specialty</h4>
                        <p className="text-gray-300 text-sm">{member.specialty}</p>
                        <div className="mt-4">
                          <a 
                            href={`mailto:${member.socials.email}`}
                            className="inline-flex items-center text-blue-400 hover:text-blue-300 transition-colors"
                          >
                            <Mail className="w-4 h-4 mr-2" />
                            Contact
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })()}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};