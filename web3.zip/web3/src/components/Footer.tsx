import React from 'react';
import { Twitter, Linkedin, Github, Mail, Heart } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="relative bg-gradient-to-b from-gray-50 to-gray-100 dark:from-gray-800 dark:to-gray-900 border-t border-gray-200 dark:border-gray-700/20">
      <div className="container mx-auto px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          {/* Brand */}
          <div className="col-span-1 md:col-span-2">
            <div className="text-3xl font-bold mb-4 bg-gradient-to-r from-teal-400 to-purple-600 bg-clip-text text-transparent">
              CryptoVerse
            </div>
            <p className="text-gray-700 dark:text-gray-300 mb-6 leading-relaxed max-w-md">
              Empowering the next generation of Web3 users through innovative technology, expert insights, and community-driven experiences.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="p-3 rounded-full bg-gray-200 dark:bg-gray-700/20 hover:bg-blue-500 hover:text-white transition-all duration-300 transform hover:scale-110">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="p-3 rounded-full bg-gray-200 dark:bg-gray-700/20 hover:bg-blue-600 hover:text-white transition-all duration-300 transform hover:scale-110">
                <Linkedin className="w-5 h-5" />
              </a>
              <a href="#" className="p-3 rounded-full bg-gray-200 dark:bg-gray-700/20 hover:bg-gray-800 hover:text-white transition-all duration-300 transform hover:scale-110">
                <Github className="w-5 h-5" />
              </a>
              <a href="#" className="p-3 rounded-full bg-gray-200 dark:bg-gray-700/20 hover:bg-teal-500 hover:text-white transition-all duration-300 transform hover:scale-110">
                <Mail className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-bold text-gray-900 dark:text-gray-200 mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li><a href="/" className="text-gray-700 dark:text-gray-300 hover:text-teal-500 dark:hover:text-teal-400 transition-colors">Home</a></li>
              <li><a href="/about" className="text-gray-700 dark:text-gray-300 hover:text-teal-500 dark:hover:text-teal-400 transition-colors">About</a></li>
              <li><a href="/features" className="text-gray-700 dark:text-gray-300 hover:text-teal-500 dark:hover:text-teal-400 transition-colors">Features</a></li>
              <li><a href="/resources" className="text-gray-700 dark:text-gray-300 hover:text-teal-500 dark:hover:text-teal-400 transition-colors">Resources</a></li>
              <li><a href="/team" className="text-gray-700 dark:text-gray-300 hover:text-teal-500 dark:hover:text-teal-400 transition-colors">Team</a></li>
              <li><a href="/contact" className="text-gray-700 dark:text-gray-300 hover:text-teal-500 dark:hover:text-teal-400 transition-colors">Contact</a></li>
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h4 className="font-bold text-gray-900 dark:text-gray-200 mb-4">Resources</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-700 dark:text-gray-300 hover:text-teal-500 dark:hover:text-teal-400 transition-colors">Beginner's Guide</a></li>
              <li><a href="#" className="text-gray-700 dark:text-gray-300 hover:text-teal-500 dark:hover:text-teal-400 transition-colors">Glossary</a></li>
              <li><a href="#" className="text-gray-700 dark:text-gray-300 hover:text-teal-500 dark:hover:text-teal-400 transition-colors">Market Analysis</a></li>
              <li><a href="#" className="text-gray-700 dark:text-gray-300 hover:text-teal-500 dark:hover:text-teal-400 transition-colors">Tools & Calculators</a></li>
              <li><a href="#" className="text-gray-700 dark:text-gray-300 hover:text-teal-500 dark:hover:text-teal-400 transition-colors">FAQ</a></li>
              <li><a href="#" className="text-gray-700 dark:text-gray-300 hover:text-teal-500 dark:hover:text-teal-400 transition-colors">Support</a></li>
            </ul>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-gray-300 dark:border-gray-700/20 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="text-gray-700 dark:text-gray-300 text-sm mb-4 md:mb-0">
              © 2025 CryptoVerse. All rights reserved. Built with{' '}
              <Heart className="inline w-4 h-4 text-red-500 mx-1" />
              for the Web3 community.
            </div>
            <div className="flex space-x-6 text-sm">
              <a href="#" className="text-gray-700 dark:text-gray-300 hover:text-teal-500 dark:hover:text-teal-400 transition-colors">
                Privacy Policy
              </a>
              <a href="#" className="text-gray-700 dark:text-gray-300 hover:text-teal-500 dark:hover:text-teal-400 transition-colors">
                Terms of Service
              </a>
              <a href="#" className="text-gray-700 dark:text-gray-300 hover:text-teal-500 dark:hover:text-teal-400 transition-colors">
                Cookie Policy
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};