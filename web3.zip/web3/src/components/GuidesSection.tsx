import React from 'react';
import { Clock, User, ArrowRight, BookOpen, Video, FileText } from 'lucide-react';

export const GuidesSection: React.FC = () => {
  const guides = [
    {
      type: "Article",
      icon: FileText,
      title: "Complete Beginner's Guide to Cryptocurrency",
      excerpt: "Everything you need to know to get started with crypto, from setting up your first wallet to making your first trade.",
      author: "Sarah Chen",
      readTime: "12 min read",
      image: "https://images.pexels.com/photos/730547/pexels-photo-730547.jpeg?auto=compress&cs=tinysrgb&w=400"
    },
    {
      type: "Video Course",
      icon: Video,
      title: "Understanding Smart Contracts",
      excerpt: "A comprehensive video series explaining how smart contracts work and their real-world applications.",
      author: "Michael Rodriguez",
      readTime: "45 min watch",
      image: "https://images.pexels.com/photos/577585/pexels-photo-577585.jpeg?auto=compress&cs=tinysrgb&w=400"
    },
    {
      type: "Guide",
      icon: BookOpen,
      title: "DeFi Yield Farming Strategies",
      excerpt: "Learn advanced strategies for maximizing returns in decentralized finance protocols safely.",
      author: "Alex Thompson",
      readTime: "8 min read",
      image: "https://images.pexels.com/photos/1181677/pexels-photo-1181677.jpeg?auto=compress&cs=tinysrgb&w=400"
    },
    {
      type: "Article",
      icon: FileText,
      title: "NFT Marketplace Analysis",
      excerpt: "Deep dive into the most popular NFT marketplaces and how to evaluate digital collectibles.",
      author: "Emma Davis",
      readTime: "15 min read",
      image: "https://images.pexels.com/photos/7686734/pexels-photo-7686734.jpeg?auto=compress&cs=tinysrgb&w=400"
    },
    {
      type: "Guide",
      icon: BookOpen,
      title: "Crypto Security Best Practices",
      excerpt: "Essential security measures every crypto investor should implement to protect their assets.",
      author: "David Kim",
      readTime: "10 min read",
      image: "https://images.pexels.com/photos/60504/security-protection-anti-virus-software-60504.jpeg?auto=compress&cs=tinysrgb&w=400"
    },
    {
      type: "Video Course",
      icon: Video,
      title: "Building Your First dApp",
      excerpt: "Step-by-step tutorial for creating a decentralized application on the Ethereum blockchain.",
      author: "Lisa Wang",
      readTime: "2 hr course",
      image: "https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg?auto=compress&cs=tinysrgb&w=400"
    }
  ];

  return (
    <section id="guides" className="py-20 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-gray-50/50 to-white/50 dark:from-gray-900/50 dark:to-gray-800/50"></div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-teal-600 to-blue-600 bg-clip-text text-transparent">
            Guides & Resources
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto leading-relaxed">
            Comprehensive guides, tutorials, and resources to accelerate your Web3 learning journey.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {guides.map((guide, index) => (
            <article 
              key={index} 
              className="group backdrop-blur-sm bg-white/40 dark:bg-gray-800/40 rounded-2xl overflow-hidden border border-gray-200/20 dark:border-gray-700/20 hover:bg-white/50 dark:hover:bg-gray-800/50 transition-all duration-300 transform hover:-translate-y-2 hover:shadow-2xl cursor-pointer"
            >
              <div className="relative overflow-hidden h-48">
                <img 
                  src={guide.image} 
                  alt={guide.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute top-4 left-4">
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-white/90 text-gray-800 backdrop-blur-sm">
                    <guide.icon className="w-3 h-3 mr-1" />
                    {guide.type}
                  </span>
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-bold mb-3 text-gray-800 dark:text-gray-200 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors line-clamp-2">
                  {guide.title}
                </h3>
                <p className="text-gray-600 dark:text-gray-300 mb-4 line-clamp-3 leading-relaxed">
                  {guide.excerpt}
                </p>
                
                <div className="flex items-center justify-between text-sm text-gray-500 dark:text-gray-400 mb-4">
                  <div className="flex items-center space-x-1">
                    <User className="w-4 h-4" />
                    <span>{guide.author}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Clock className="w-4 h-4" />
                    <span>{guide.readTime}</span>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <button className="flex items-center text-blue-600 dark:text-blue-400 font-semibold hover:text-blue-700 dark:hover:text-blue-300 transition-colors">
                    Read More
                    <ArrowRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>

        <div className="text-center mt-12">
          <button className="group bg-gradient-to-r from-teal-500 to-blue-600 hover:from-teal-600 hover:to-blue-700 text-white px-8 py-3 rounded-full font-semibold transition-all duration-300 transform hover:scale-105 hover:shadow-2xl hover:shadow-teal-500/25">
            Browse All Guides
            <span className="inline-block ml-2 group-hover:translate-x-1 transition-transform">→</span>
          </button>
        </div>
      </div>
    </section>
  );
};