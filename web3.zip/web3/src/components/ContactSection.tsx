import React, { useState } from 'react';
import { Mail, MessageCircle, Send } from 'lucide-react';

export const ContactSection: React.FC = () => {
  const [email, setEmail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setIsSubscribed(true);
      setTimeout(() => setIsSubscribed(false), 3000);
      setEmail('');
    }
  };

  return (
    <section id="contact" className="py-20 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-gray-50/50 to-white/50 dark:from-gray-900/50 dark:to-gray-800/50"></div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-blue-600 to-teal-600 bg-clip-text text-transparent">
            Stay Updated
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-12 leading-relaxed">
            Subscribe to our newsletter for the latest Web3 insights, market updates, and educational content delivered to your inbox.
          </p>

          <div className="backdrop-blur-sm bg-white/40 dark:bg-gray-800/40 rounded-3xl p-8 md:p-12 border border-gray-200/20 dark:border-gray-700/20 mb-12">
            <form onSubmit={handleSubmit} className="max-w-md mx-auto">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1 relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your email address"
                    className="w-full pl-12 pr-4 py-3 rounded-full bg-white/50 dark:bg-gray-700/50 border border-gray-300/50 dark:border-gray-600/50 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-transparent backdrop-blur-sm text-gray-800 dark:text-gray-200 placeholder-gray-500 dark:placeholder-gray-400"
                    required
                  />
                </div>
                <button
                  type="submit"
                  className="group bg-gradient-to-r from-blue-500 to-teal-600 hover:from-blue-600 hover:to-teal-700 text-white px-8 py-3 rounded-full font-semibold transition-all duration-300 transform hover:scale-105 hover:shadow-2xl hover:shadow-blue-500/25 flex items-center justify-center"
                >
                  Subscribe
                  <Send className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
              
              {isSubscribed && (
                <div className="mt-4 p-3 bg-green-100/80 dark:bg-green-900/20 border border-green-200/50 dark:border-green-700/50 rounded-full text-green-700 dark:text-green-400 font-semibold text-center backdrop-blur-sm">
                  ✅ Thank you for subscribing! Welcome to the community.
                </div>
              )}
            </form>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="backdrop-blur-sm bg-white/30 dark:bg-gray-800/30 rounded-2xl p-8 border border-gray-200/20 dark:border-gray-700/20">
              <Mail className="w-12 h-12 text-blue-500 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-3 text-gray-800 dark:text-gray-200">
                Email Support
              </h3>
              <p className="text-gray-600 dark:text-gray-300 mb-4">
                Have questions? Reach out to our team for personalized assistance.
              </p>
              <a 
                href="mailto:support@cryptoedu.com"
                className="text-blue-600 dark:text-blue-400 font-semibold hover:underline"
              >
                support@cryptoedu.com
              </a>
            </div>

            <div className="backdrop-blur-sm bg-white/30 dark:bg-gray-800/30 rounded-2xl p-8 border border-gray-200/20 dark:border-gray-700/20">
              <MessageCircle className="w-12 h-12 text-teal-500 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-3 text-gray-800 dark:text-gray-200">
                Community Chat
              </h3>
              <p className="text-gray-600 dark:text-gray-300 mb-4">
                Join our active Discord community for real-time discussions and support.
              </p>
              <button className="text-teal-600 dark:text-teal-400 font-semibold hover:underline">
                Join Discord →
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};