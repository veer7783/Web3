import React from 'react';
import { Target, Users, BookOpen, Lightbulb } from 'lucide-react';

export const AboutSection: React.FC = () => {
  const features = [
    {
      icon: Target,
      title: "Our Mission",
      description: "To democratize Web3 education and make cryptocurrency accessible to everyone, regardless of technical background."
    },
    {
      icon: Users,
      title: "Community First",
      description: "Building a supportive learning community where beginners and experts collaborate to advance blockchain knowledge."
    },
    {
      icon: BookOpen,
      title: "Comprehensive Learning",
      description: "From basic concepts to advanced strategies, we provide structured pathways for continuous growth in Web3."
    },
    {
      icon: Lightbulb,
      title: "Innovation Focus",
      description: "Staying ahead of the curve with the latest developments, trends, and opportunities in the crypto space."
    }
  ];

  return (
    <section id="about" className="py-20 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-gray-50/50 to-white/50 dark:from-gray-900/50 dark:to-gray-800/50"></div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-purple-600 to-teal-600 bg-clip-text text-transparent">
            About CryptoEdu
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto leading-relaxed">
            We're passionate educators and blockchain enthusiasts dedicated to bridging the gap between complex Web3 technologies and everyday understanding.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="group backdrop-blur-sm bg-white/20 dark:bg-gray-800/20 rounded-2xl p-8 border border-gray-200/20 dark:border-gray-700/20 hover:bg-white/30 dark:hover:bg-gray-800/30 transition-all duration-300 transform hover:-translate-y-2 hover:shadow-2xl"
            >
              <div className="mb-6 relative">
                <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-full blur-xl group-hover:blur-2xl transition-all duration-300"></div>
                <feature.icon className="w-12 h-12 text-blue-500 relative z-10 mx-auto group-hover:scale-110 transition-transform duration-300" />
              </div>
              <h3 className="text-xl font-bold mb-4 text-gray-800 dark:text-gray-200 text-center">
                {feature.title}
              </h3>
              <p className="text-gray-600 dark:text-gray-300 text-center leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};