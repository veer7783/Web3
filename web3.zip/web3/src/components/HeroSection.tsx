import React from 'react';
import { ArrowRight, Zap, Shield, Coins } from 'lucide-react';

export const HeroSection: React.FC = () => {
  return (
    <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Background gradients */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 via-blue-900/20 to-teal-900/20 dark:from-purple-900/40 dark:via-blue-900/40 dark:to-teal-900/40"></div>
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-gradient-to-r from-teal-500/10 to-blue-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>

      <div className="container mx-auto px-6 py-20 relative z-10">
        <div className="text-center max-w-4xl mx-auto">
          {/* Floating icons */}
          <div className="flex justify-center space-x-8 mb-8 opacity-60">
            <div className="animate-bounce delay-100">
              <Zap className="w-8 h-8 text-yellow-500" />
            </div>
            <div className="animate-bounce delay-300">
              <Shield className="w-8 h-8 text-teal-500" />
            </div>
            <div className="animate-bounce delay-500">
              <Coins className="w-8 h-8 text-purple-500" />
            </div>
          </div>

          <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-blue-400 via-purple-500 to-teal-400 bg-clip-text text-transparent animate-pulse">
            Master Web3
            <br />
            <span className="text-4xl md:text-6xl">& Cryptocurrency</span>
          </h1>

          <p className="text-xl md:text-2xl text-gray-600 dark:text-gray-300 mb-8 max-w-3xl mx-auto leading-relaxed">
            Unlock the future of finance with comprehensive guides, expert insights, and practical knowledge to navigate the blockchain revolution confidently.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
            <button className="group bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white px-8 py-4 rounded-full text-lg font-semibold transition-all duration-300 transform hover:scale-105 hover:shadow-2xl hover:shadow-purple-500/25">
              Start Learning
              <ArrowRight className="inline-block ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
            <button className="px-8 py-4 rounded-full text-lg font-semibold border-2 border-teal-500 text-teal-600 dark:text-teal-400 hover:bg-teal-500 hover:text-white transition-all duration-300 transform hover:scale-105">
              Explore Topics
            </button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-2xl mx-auto">
            <div className="backdrop-blur-sm bg-white/10 dark:bg-gray-800/10 rounded-lg p-6 border border-gray-200/20 dark:border-gray-700/20">
              <div className="text-3xl font-bold text-blue-500 mb-2">100+</div>
              <div className="text-gray-600 dark:text-gray-300">Educational Articles</div>
            </div>
            <div className="backdrop-blur-sm bg-white/10 dark:bg-gray-800/10 rounded-lg p-6 border border-gray-200/20 dark:border-gray-700/20">
              <div className="text-3xl font-bold text-purple-500 mb-2">50K+</div>
              <div className="text-gray-600 dark:text-gray-300">Active Learners</div>
            </div>
            <div className="backdrop-blur-sm bg-white/10 dark:bg-gray-800/10 rounded-lg p-6 border border-gray-200/20 dark:border-gray-700/20">
              <div className="text-3xl font-bold text-teal-500 mb-2">24/7</div>
              <div className="text-gray-600 dark:text-gray-300">Community Support</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};