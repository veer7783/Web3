import React from 'react';
import { Linkedin, Twitter, Github } from 'lucide-react';

export const TeamSection: React.FC = () => {
  const teamMembers = [
    {
      name: "Sarah Chen",
      role: "Lead Blockchain Educator",
      bio: "Former Goldman Sachs analyst with 8+ years in crypto education.",
      image: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=300",
      socials: { twitter: "#", linkedin: "#", github: "#" }
    },
    {
      name: "Michael Rodriguez",
      role: "Smart Contract Developer",
      bio: "Full-stack developer specializing in Ethereum and Web3 applications.",
      image: "https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg?auto=compress&cs=tinysrgb&w=300",
      socials: { twitter: "#", linkedin: "#", github: "#" }
    },
    {
      name: "Alex Thompson",
      role: "DeFi Research Analyst",
      bio: "Economics PhD focusing on decentralized finance and tokenomics.",
      image: "https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=300",
      socials: { twitter: "#", linkedin: "#", github: "#" }
    },
    {
      name: "Emma Davis",
      role: "NFT & Digital Art Specialist",
      bio: "Art curator turned digital asset expert with deep market insights.",
      image: "https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=300",
      socials: { twitter: "#", linkedin: "#", github: "#" }
    }
  ];

  return (
    <section id="team" className="py-20 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-white/50 to-gray-50/50 dark:from-gray-800/50 dark:to-gray-900/50"></div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
            Meet Our Team
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto leading-relaxed">
            Passionate experts and educators dedicated to making Web3 knowledge accessible to everyone.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {teamMembers.map((member, index) => (
            <div 
              key={index} 
              className="group backdrop-blur-sm bg-white/40 dark:bg-gray-800/40 rounded-2xl p-8 border border-gray-200/20 dark:border-gray-700/20 hover:bg-white/50 dark:hover:bg-gray-800/50 transition-all duration-300 transform hover:-translate-y-2 hover:shadow-2xl text-center"
            >
              <div className="relative mb-6">
                <div className="absolute inset-0 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-full blur-xl group-hover:blur-2xl transition-all duration-300"></div>
                <img 
                  src={member.image} 
                  alt={member.name}
                  className="w-24 h-24 rounded-full mx-auto object-cover border-4 border-white/20 dark:border-gray-700/20 relative z-10 group-hover:scale-110 transition-transform duration-300"
                />
              </div>
              
              <h3 className="text-xl font-bold mb-2 text-gray-800 dark:text-gray-200">
                {member.name}
              </h3>
              <p className="text-purple-600 dark:text-purple-400 font-semibold mb-3">
                {member.role}
              </p>
              <p className="text-gray-600 dark:text-gray-300 text-sm leading-relaxed mb-6">
                {member.bio}
              </p>
              
              <div className="flex justify-center space-x-4">
                <a 
                  href={member.socials.twitter} 
                  className="p-2 rounded-full bg-gray-200/20 dark:bg-gray-700/20 hover:bg-blue-500 hover:text-white transition-all duration-300 transform hover:scale-110"
                >
                  <Twitter className="w-4 h-4" />
                </a>
                <a 
                  href={member.socials.linkedin} 
                  className="p-2 rounded-full bg-gray-200/20 dark:bg-gray-700/20 hover:bg-blue-600 hover:text-white transition-all duration-300 transform hover:scale-110"
                >
                  <Linkedin className="w-4 h-4" />
                </a>
                <a 
                  href={member.socials.github} 
                  className="p-2 rounded-full bg-gray-200/20 dark:bg-gray-700/20 hover:bg-gray-800 hover:text-white transition-all duration-300 transform hover:scale-110"
                >
                  <Github className="w-4 h-4" />
                </a>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-16">
          <h3 className="text-2xl font-bold mb-4 text-gray-800 dark:text-gray-200">
            Join Our Community
          </h3>
          <p className="text-gray-600 dark:text-gray-300 mb-6 max-w-2xl mx-auto">
            Connect with thousands of learners, ask questions, and stay updated with the latest in Web3.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white px-6 py-3 rounded-full font-semibold transition-all duration-300 transform hover:scale-105">
              Join Discord
            </button>
            <button className="border-2 border-teal-500 text-teal-600 dark:text-teal-400 hover:bg-teal-500 hover:text-white px-6 py-3 rounded-full font-semibold transition-all duration-300 transform hover:scale-105">
              Follow on Twitter
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};