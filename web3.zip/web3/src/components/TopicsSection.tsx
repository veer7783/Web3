import React from 'react';
import { Link, Coins, Shield, Zap, Database, Globe, Cpu } from 'lucide-react';

export const TopicsSection: React.FC = () => {
  const topics = [
    {
      icon: Link,
      title: "Blockchain Fundamentals",
      description: "Understand the core concepts of distributed ledgers, consensus mechanisms, and decentralization.",
      gradient: "from-blue-500 to-cyan-500",
      bgGradient: "from-blue-500/10 to-cyan-500/10"
    },
    {
      icon: Coins,
      title: "Cryptocurrency Basics",
      description: "Learn about Bitcoin, Ethereum, altcoins, and how digital currencies work.",
      gradient: "from-yellow-500 to-orange-500",
      bgGradient: "from-yellow-500/10 to-orange-500/10"
    },
    {
      icon: Shield,
      title: "Security & Wallets",
      description: "Master wallet security, private keys, and best practices for protecting your assets.",
      gradient: "from-green-500 to-emerald-500",
      bgGradient: "from-green-500/10 to-emerald-500/10"
    },
    {
      icon: Zap,
      title: "DeFi Ecosystem",
      description: "Explore decentralized finance, yield farming, liquidity pools, and DeFi protocols.",
      gradient: "from-purple-500 to-pink-500",
      bgGradient: "from-purple-500/10 to-pink-500/10"
    },
    {
      icon: Database,
      title: "NFTs & Digital Assets",
      description: "Understand non-fungible tokens, digital ownership, and the creator economy.",
      gradient: "from-indigo-500 to-blue-500",
      bgGradient: "from-indigo-500/10 to-blue-500/10"
    },
    {
      icon: Globe,
      title: "Web3 Applications",
      description: "Discover dApps, smart contracts, and the decentralized web ecosystem.",
      gradient: "from-teal-500 to-green-500",
      bgGradient: "from-teal-500/10 to-green-500/10"
    },
    {
      icon: Cpu,
      title: "Mining & Staking",
      description: "Learn about proof-of-work, proof-of-stake, and earning rewards in crypto.",
      gradient: "from-red-500 to-pink-500",
      bgGradient: "from-red-500/10 to-pink-500/10"
    },
    {
      icon: Shield,
      title: "Regulatory Landscape",
      description: "Stay informed about crypto regulations, compliance, and legal considerations.",
      gradient: "from-gray-600 to-gray-800",
      bgGradient: "from-gray-600/10 to-gray-800/10"
    }
  ];

  return (
    <section id="topics" className="py-20 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-white/50 to-gray-50/50 dark:from-gray-800/50 dark:to-gray-900/50"></div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Core Learning Topics
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto leading-relaxed">
            Master the essential concepts that form the foundation of Web3 and cryptocurrency knowledge.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {topics.map((topic, index) => (
            <div 
              key={index} 
              className="group backdrop-blur-sm bg-white/30 dark:bg-gray-800/30 rounded-2xl p-6 border border-gray-200/20 dark:border-gray-700/20 hover:bg-white/40 dark:hover:bg-gray-800/40 transition-all duration-300 transform hover:-translate-y-2 hover:shadow-2xl cursor-pointer"
            >
              <div className="mb-4 relative">
                <div className={`absolute inset-0 bg-gradient-to-r ${topic.bgGradient} rounded-full blur-xl group-hover:blur-2xl transition-all duration-300`}></div>
                <div className={`w-12 h-12 rounded-full bg-gradient-to-r ${topic.gradient} flex items-center justify-center relative z-10 mx-auto group-hover:scale-110 transition-transform duration-300`}>
                  <topic.icon className="w-6 h-6 text-white" />
                </div>
              </div>
              <h3 className="text-lg font-bold mb-3 text-gray-800 dark:text-gray-200 text-center group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                {topic.title}
              </h3>
              <p className="text-gray-600 dark:text-gray-300 text-center text-sm leading-relaxed">
                {topic.description}
              </p>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <button className="group bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white px-8 py-3 rounded-full font-semibold transition-all duration-300 transform hover:scale-105 hover:shadow-2xl hover:shadow-purple-500/25">
            View All Topics
            <span className="inline-block ml-2 group-hover:translate-x-1 transition-transform">→</span>
          </button>
        </div>
      </div>
    </section>
  );
};